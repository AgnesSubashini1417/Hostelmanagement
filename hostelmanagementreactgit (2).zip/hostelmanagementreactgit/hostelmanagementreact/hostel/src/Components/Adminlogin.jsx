import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Adminlogin.css"; // Import the CSS file

function Adminlogin() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");

  // Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle Login Submission
  const handleSubmit = (e) => {
    e.preventDefault();

    // Hardcoded admin credentials
    if (formData.email === "admin@gmail.com" && formData.password === "admin") {
      alert("Login successful!");
      navigate("/admindash"); // Redirect to Admin Dashboard
    } else {
      setError("Invalid email or password.");
    }
  };

  return (
    <div className="admin-container">
      {/* Title */}
      <h1 className="title">Hostel Management System</h1>

      {/* Login Form */}
      <div className="login-box">
        <h2>Admin Login</h2>
        {error && <p className="error-message">{error}</p>}
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Email</label>
            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="input-group">
            <label>Password</label>
            <input
              type="password"
              name="password"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="login-btn">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

export default Adminlogin;
