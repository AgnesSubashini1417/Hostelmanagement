import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  TextField,
  Paper,
  MenuItem,
} from "@mui/material";
import "./Feedback.css";

const Feedback = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    roomNo: "",
    warden: "",
    committee: "",
    room: "",
    mess: "",
    surrounding: "",
    rating: "",
    message: "",
  });

  // Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle feedback submission
  const handleSubmit = async () => {
    // Check for empty fields
    if (Object.values(formData).some((value) => value.trim() === "")) {
      alert("Please fill all fields before submitting.");
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost/hostelreact/controllers/api/user/Feedback.php",
        formData,
        { headers: { "Content-Type": "application/json" } }
      );

      if (response.data.success) {
        alert("Feedback submitted successfully!");
        setFormData({
          name: "",
          roomNo: "",
          warden: "",
          committee: "",
          room: "",
          mess: "",
          surrounding: "",
          rating: "",
          message: "",
        });
      } else {
        alert("Failed to submit feedback: " + response.data.message);
      }
    } catch (error) {
      console.error("Error submitting feedback:", error);
      alert("An error occurred. Please try again.");
    }
  };

  // Handle Logout
  const handleLogout = () => {
    navigate("/");
  };

  return (
    <Box className="feedback-container">
      {/* Navbar */}
      <AppBar position="fixed" className="navbar">
        <Toolbar className="navbar-toolbar">
          <Typography variant="h6" className="navbar-title">
            Hostel Management
          </Typography>
          <div className="navbar-buttons">
            <Button color="inherit" onClick={() => navigate("/viewrooms")}>
              View Rooms
            </Button>
            <Button color="inherit" onClick={() => navigate("/complaints")}>
              Complaints
            </Button>
            <Button color="inherit" onClick={() => navigate("/viewcomplaints")}>
              View Complaints
            </Button>
            <Button color="inherit" onClick={() => navigate("/feedback")}>
              Feedback
            </Button>
            <Button color="inherit" className="logout-button" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </Toolbar>
      </AppBar>

      {/* Feedback Form */}
      <Paper elevation={3} className="feedback-form-paper">
        <Typography variant="h5" className="feedback-form-title">
          Submit Your Feedback
        </Typography>

        <TextField
          label="Your Name"
          variant="outlined"
          fullWidth
          margin="dense"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />

        <TextField
          label="Room Number"
          variant="outlined"
          fullWidth
          margin="dense"
          name="roomNo"
          value={formData.roomNo}
          onChange={handleChange}
          required
        />

        {["warden", "committee", "room", "mess", "surrounding", "rating"].map((field) => (
          <TextField
            key={field}
            select
            label={field.replace(/^\w/, (c) => c.toUpperCase())}
            variant="outlined"
            fullWidth
            margin="dense"
            name={field}
            value={formData[field]}
            onChange={handleChange}
            required
          >
            <MenuItem value="Good">Good</MenuItem>
            <MenuItem value="Average">Average</MenuItem>
            <MenuItem value="Poor">Poor</MenuItem>
          </TextField>
        ))}

        <TextField
          label="Feedback Message"
          variant="outlined"
          fullWidth
          multiline
          rows={4}
          margin="dense"
          name="message"
          value={formData.message}
          onChange={handleChange}
          required
        />

        <Button variant="contained" color="primary" fullWidth onClick={handleSubmit} className="submit-button">
          Submit Feedback
        </Button>
      </Paper>
    </Box>
  );
};

export default Feedback;
