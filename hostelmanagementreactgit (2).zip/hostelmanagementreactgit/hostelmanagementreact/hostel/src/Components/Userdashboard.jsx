import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Grid,
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
} from "@mui/material";
import "./Userdashboard.css";

// Import room images
import oneSeater from "../assets/oneseater.webp";
import twoSeater from "../assets/twoseater.webp";
import tripleSeater from "../assets/tripleseater.jpg";
import multipleSeater from "../assets/multipleseater.jpg";
import multipleSeaterAC from "../assets/multipleseaterAC.jpg";
import singleSeaterAC from "../assets/multipleseater.jpg";

// Room details
const rooms = [
  { id: 1, roomNo: "101", name: "One Seater", price: 5000, image: oneSeater },
  { id: 2, roomNo: "102", name: "Two Seater", price: 4000, image: twoSeater },
  { id: 3, roomNo: "103", name: "Triple Seater", price: 3000, image: tripleSeater },
  { id: 4, roomNo: "104", name: "Multiple Seater", price: 2800, image: multipleSeater },
  { id: 5, roomNo: "105", name: "Multiple Seater AC", price: 7000, image: multipleSeaterAC },
  { id: 6, roomNo: "106", name: "Single Seater AC", price: 10000, image: singleSeaterAC },
];

const Userdashboard = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    regNo: "",
    address: "",
    contact: "",
    guardian: "",
    permanentAddress: "",
    joinDate: "",
    price: "",
    roomNo: "",
    room: "",
  });

  // Open Booking Dialog
  const handleJoinNow = (room) => {
    setSelectedRoom(room);
    setFormData({ ...formData, price: room.price, roomNo: room.roomNo, room: room.name });
    setOpen(true);
  };

  // Close Dialog
  const handleClose = () => {
    setOpen(false);
    setFormData({
      name: "",
      regNo: "",
      address: "",
      contact: "",
      guardian: "",
      permanentAddress: "",
      joinDate: "",
      price: "",
      roomNo: "",
      room: "",
    });
  };

  // Handle Form Input Change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle Booking Submission
  const handleSubmit = async () => {
    if (!formData.name || !formData.regNo || !formData.contact || !formData.joinDate) {
      alert("Please fill all required fields.");
      return;
    }

    try {
      const response = await axios.post("http://localhost/hostelreact/controllers/api/user/bookroom.php", formData);

      if (response.data.success) {
        alert("Room booked successfully!");
        handleClose();
      } else {
        alert("Booking failed: " + response.data.message);
      }
    } catch (error) {
      console.error("Error booking room:", error);
      alert("An error occurred. Please try again.");
    }
  };

  return (
    <Box className="dashboard-container">
      {/* Navbar */}
      <AppBar position="static" className="navbar">
        <Toolbar>
          <Typography variant="h6" className="navbar-title">Hostel Management</Typography>
          <Box className="navbar-buttons" style={{ marginLeft: "auto" }}>
            <Button color="inherit" >View Rooms</Button>
            <Button color="inherit" onClick={() => navigate("/complaints")}>Complaints</Button>

            <Button color="inherit" onClick={() => navigate("/feedback")}>Feedback</Button>
            <Button color="inherit" onClick={() => navigate("/viewcomplaint")}>View Complaints</Button>
            <Button color="inherit" onClick={() => navigate("/")}>Logout</Button>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Room Grid */}
      <Grid container spacing={3} justifyContent="center">
        {rooms.map((room) => (
          <Grid key={room.id} item xs={12} sm={6} md={4}>
            <div className="card">
              <img src={room.image} alt={room.name} className="room-img" />
              <Typography variant="h6" className="room-title">{room.name}</Typography>
              <Typography variant="body1" className="room-price">₹{room.price}/month</Typography>
              <Typography variant="body2" className="room-no">Room No: {room.roomNo}</Typography>
              <Button variant="contained" className="join-button" onClick={() => handleJoinNow(room)}>
                Book Now
              </Button>
            </div>
          </Grid>
        ))}
      </Grid>

      {/* Booking Dialog */}
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Room Booking Details</DialogTitle>
        <DialogContent>
          <Typography><strong>Room No:</strong> {selectedRoom?.roomNo}</Typography>
          <Typography><strong>Room:</strong> {selectedRoom?.name}</Typography>
          <Typography><strong>Price:</strong> ₹{selectedRoom?.price}/month</Typography>
          {Object.keys(formData).map((key) => (
            key !== "roomNo" && key !== "room" && key !== "price" && (
              <TextField
                key={key}
                label={key.replace(/([A-Z])/g, " $1").trim()}
                variant="outlined"
                fullWidth
                margin="dense"
                name={key}
                value={formData[key]}
                onChange={handleChange}
                type={key === "joinDate" ? "date" : "text"}
                InputLabelProps={key === "joinDate" ? { shrink: true } : {}}
              />
            )
          ))}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">Cancel</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">Submit Booking</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Userdashboard;
