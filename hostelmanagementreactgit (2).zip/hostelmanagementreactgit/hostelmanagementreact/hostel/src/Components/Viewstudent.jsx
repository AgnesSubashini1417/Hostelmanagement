import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import "./Viewstudent.css"; // Import CSS file

const StudentRegistration = () => {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState("");

  // Fetch student data from backend API
  useEffect(() => {
    axios
      .get("http://localhost/hostelreact/controllers/api/admin/getstudents.php")
      .then((response) => {
        if (response.data.success) {
          setStudents(response.data.students);
        } else {
          setError("No student data available.");
        }
      })
      .catch((error) => {
        console.error("Error fetching students:", error);
        setError("Failed to fetch student data.");
      });
  }, []);

  return (
    <div className="admin-dashboard">
      {/* Header */}
      <div className="header">
        <h2>🏠 Hostel Management System</h2>
      </div>

      {/* Dashboard Body */}
      <div className="dashboard-body">
        {/* Sidebar */}
        <div className="sidebar">
          <div className="sidebar-content">
            <NavLink to="/admindash" className="nav-link">
              <Button variant="outline-light">📊 Dashboard</Button>
            </NavLink>
            <NavLink to="/studentreg" className="nav-link">
              <Button variant="outline-light">📝 View Student Registration</Button>
            </NavLink>
            <NavLink to="/managerooms" className="nav-link">
              <Button variant="outline-light">🏠 Manage Rooms</Button>
            </NavLink>
            <NavLink to="/admincomplaint" className="nav-link">
              <Button variant="outline-light">📩 View Complaints</Button>
            </NavLink>
            <NavLink to="/allfeedback" className="nav-link">
              <Button variant="outline-light">💬 Feedback</Button>
            </NavLink>
            <NavLink to="/" className="nav-link">
              <Button variant="outline-danger">🚪 Log Out</Button>
            </NavLink>
          </div>
        </div>

        {/* Main Content */}
        <div className="main-content">
          <div className="content-container">
            <h3 className="section-title">📌 Student Registration Details</h3>

            {/* Table Design */}
            {error ? (
              <p className="error-message">{error}</p>
            ) : (
              <div className="table-container">
                <table className="student-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Age</th>
                      <th>Father Name</th>
                      <th>Gender</th>
                      <th>Phone No</th>
                      <th>Email</th>
                      <th>Address</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student, index) => (
                      <tr key={index}>
                        <td>{student.name}</td>
                        <td>{student.age}</td>
                        <td>{student.fathername}</td>
                        <td>{student.gender}</td>
                        <td>{student.phoneno}</td>
                        <td>{student.email}</td>
                        <td>{student.address}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentRegistration;
