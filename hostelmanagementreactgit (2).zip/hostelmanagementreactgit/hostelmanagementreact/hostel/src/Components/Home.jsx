import React from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "./Home.css"; // Import the CSS file

function Home() {
  const navigate = useNavigate(); // Initialize navigation

  return (
    <div className="home-container">
      {/* Title */}
      <h1 className="title">Hostel Management System</h1>

      {/* Buttons */}
      <div className="button-container">
        <button className="btn admin-btn" onClick={() => navigate("/adminlogin")}>
          Admin
        </button>
        <button className="btn user-btn"onClick={() => navigate("/userlogin")}>User</button>
      </div>
    </div>
  );
}

export default Home;
