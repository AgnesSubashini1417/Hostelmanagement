import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import { FaUserGraduate, FaClipboardList, FaComments } from "react-icons/fa"; // Icons
import "./Admindashboard.css";

const Admindashboard = () => {
  const [dashboardData, setDashboardData] = useState({
    total_students: 0,
    total_complaints: 0,
    total_feedback: 0,
  });

  const [error, setError] = useState("");

  useEffect(() => {
    axios
      .get("http://localhost/hostelreact/controllers/api/admin/dashboard.php", {
        withCredentials: true, // Ensures session authentication
      })
      .then((response) => {
        if (response.data.success) {
          setDashboardData(response.data);
        } else {
          setError("Failed to fetch dashboard data.");
        }
      })
      .catch((error) => {
        console.error("Error fetching dashboard data:", error);
        setError("Error fetching data.");
      });
  }, []);

  return (
    <div className="admin-dashboard">
      {/* Header */}
      <div className="header">
        <h2>🏠 Hostel Management System</h2>
      </div>

      {/* Sidebar & Main Content */}
      <div className="dashboard-body">
        {/* Sidebar */}
        <div className="sidebar">
          <div className="sidebar-content">
            <NavLink to="/admindash" className="nav-link">
              <Button variant="outline-light">📊 Dashboard</Button>
            </NavLink>
            <NavLink to="/studentreg" className="nav-link">
              <Button variant="outline-light">📝 View Student Registration</Button>
            </NavLink>
            <NavLink to="/managerooms" className="nav-link">
              <Button variant="outline-light">🏠 Manage Rooms</Button>
            </NavLink>
            <NavLink to="/admincomplaint" className="nav-link">
              <Button variant="outline-light">📩 View Complaints</Button>
            </NavLink>
            <NavLink to="/allfeedback" className="nav-link">
              <Button variant="outline-light">💬 Feedback</Button>
            </NavLink>
            <NavLink to="/" className="nav-link">
              <Button variant="outline-danger">🚪 Log Out</Button>
            </NavLink>
          </div>
        </div>

        {/* Main Content */}
        <div className="main-content">
          <div className="dashboard-boxes">
            <div className="dashboard-box">
              <FaUserGraduate className="box-icon" />
              <h3>Total Students</h3>
              <p>{dashboardData.total_students}</p>
            </div>

            <div className="dashboard-box">
              <FaClipboardList className="box-icon" />
              <h3>Complaint Details</h3>
              <p>{dashboardData.total_complaints}</p>
            </div>

            <div className="dashboard-box">
              <FaComments className="box-icon" />
              <h3>Total Feedback</h3>
              <p>{dashboardData.total_feedback}</p>
            </div>
          </div>

          {error && <p className="error-message">{error}</p>}
        </div>
      </div>
    </div>
  );
};

export default Admindashboard;
