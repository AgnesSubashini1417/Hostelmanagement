import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import "./Register.css";

function Register() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    fathername: "",
    Gender: "",
    phoneno: "",
    email: "",
    password: "",
    address: "",
  });

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");

    try {
      const response = await axios.post(
        "http://localhost/hostelreact/controllers/api/user/register.php",
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.data.success) {
        setMessage("Registration successful! Redirecting to login...");
        setTimeout(() => navigate("/userlogin"), 2000);
      } else {
        setError(response.data.message || "Registration failed!");
      }
    } catch (error) {
      setError("Error: " + error.message);
    }
  };

  return (
    <div className="register-container">
      <h1 className="register-title">User Registration</h1>

      <div className="register-box">
        {message && <p className="success-message">{message}</p>}
        {error && <p className="error-message">{error}</p>}

        <form onSubmit={handleSubmit} className="form-grid">
          <div className="input-group">
            <label>Name</label>
            <input type="text" name="name" value={formData.name} required onChange={handleChange} />
          </div>

          <div className="input-group">
            <label>Age</label>
            <input type="number" name="age" value={formData.age} required onChange={handleChange} />
          </div>

          <div className="input-group">
            <label>Father's Name</label>
            <input type="text" name="fathername" value={formData.fathername} required onChange={handleChange} />
          </div>

          <div className="input-group">
            <label>Gender</label>
            <select name="Gender" value={formData.Gender} required onChange={handleChange}>
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="input-group">
            <label>Phone No</label>
            <input type="tel" name="phoneno" value={formData.phoneno} required onChange={handleChange} />
          </div>

          <div className="input-group">
            <label>Email</label>
            <input type="email" name="email" value={formData.email} required onChange={handleChange} />
          </div>

          <div className="input-group">
            <label>Password</label>
            <input type="password" name="password" value={formData.password} required onChange={handleChange} />
          </div>

          <div className="input-group">
            <label>Address</label>
            <textarea name="address" value={formData.address} required onChange={handleChange}></textarea>
          </div>

          <button type="submit" className="register-btn">Register</button>
        </form>

        <p className="login-text">
          Already have an account? <Link to="/userlogin">Login here</Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
