import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import "./ManageRooms.css";

const ManageRooms = () => {
  const [rooms, setRooms] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    axios
      .get("http://localhost/hostelreact/controllers/api/admin/getrooms.php")
      .then((response) => {
        if (response.data.success) {
          setRooms(response.data.rooms);
        } else {
          setError("No room data available.");
        }
      })
      .catch((error) => {
        console.error("Error fetching rooms:", error);
        setError("Failed to fetch room data.");
      });
  }, []);

  return (
    <div className="admin-dashboard">
      {/* Header */}
      <div className="header">
        <h2>🏠 Hostel Management System</h2>
      </div>

      {/* Sidebar & Main Content */}
      <div className="dashboard-body">
        {/* Sidebar */}
        <div className="sidebar">
          <div className="sidebar-content">
            <NavLink to="/admindash" className="nav-link">
              <Button variant="outline-light">📊 Dashboard</Button>
            </NavLink>
            <NavLink to="/studentreg" className="nav-link">
              <Button variant="outline-light">📝 View Student Registration</Button>
            </NavLink>
            <NavLink to="/managerooms" className="nav-link">
              <Button variant="outline-light">🏠 Manage Rooms</Button>
            </NavLink>
            <NavLink to="/admincomplaint" className="nav-link">
              <Button variant="outline-light">📩 View Complaints</Button>
            </NavLink>
            <NavLink to="/allfeedback" className="nav-link">
              <Button variant="outline-light">💬 Feedback</Button>
            </NavLink>
            <NavLink to="/" className="nav-link">
              <Button variant="outline-danger">🚪 Log Out</Button>
            </NavLink>
          </div>
        </div>

        {/* Main Content */}
        <div className="main-content">
          <div className="content-container">
            <h3 className="section-title">🏠 Manage Rooms</h3>

            {error ? (
              <p className="error-message">{error}</p>
            ) : (
              <div className="table-container">
                <table className="student-table">
                  <thead>
                    <tr>
                      <th>Room No</th>
                      <th>Room Type</th>
                      <th>Price</th>
                      <th>Name</th>
                      <th>Reg No</th>
                      <th>Contact</th>
                      <th>Guardian</th>
                      <th>Address</th>
                      <th>Join Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rooms.map((room, index) => (
                      <tr key={index}>
                        <td>{room.roomno}</td>
                        <td>{room.room}</td>
                        <td>{room.price}</td>
                        <td>{room.name}</td>
                        <td>{room.regno}</td>
                        <td>{room.contact}</td>
                        <td>{room.guardian}</td>
                        <td>{room.address}</td>
                        <td>{room.joindate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageRooms;
