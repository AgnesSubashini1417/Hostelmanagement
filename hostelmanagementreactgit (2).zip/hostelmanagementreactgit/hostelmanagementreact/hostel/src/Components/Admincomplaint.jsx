import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import "./Admincomplaint.css";

const Admincomplaint = () => {
  const [complaints, setComplaints] = useState([]);
  const [error, setError] = useState("");

  // Fetch complaints
  useEffect(() => {
    axios
      .get("http://localhost/hostelreact/controllers/api/admin/viewcomplaints.php") // Ensure correct path
      .then((response) => {
        if (response.data.success) {
          setComplaints(response.data.complaints);
        } else {
          setError(response.data.message);
        }
      })
      .catch(() => setError("Error fetching complaints"));
  }, []);

  // Update complaint status
  const updateStatus = (id, status) => {
    axios
      .post("http://localhost/hostelreact/controllers/api/admin/viewcomplaints.php", { id, status }) // Ensure correct path
      .then((response) => {
        if (response.data.success) {
          setComplaints((prevComplaints) =>
            prevComplaints.map((complaint) =>
              complaint.id === id ? { ...complaint, status } : complaint
            )
          );
        } else {
          alert("Failed to update status");
        }
      })
      .catch(() => alert("Error updating complaint status"));
  };

  return (
    <div className="admin-dashboard">
      <div className="header">
        <h2>📩 View Complaints</h2>
      </div>

      <div className="dashboard-body">
        <div className="sidebar">
          <div className="sidebar-content">
            <NavLink to="/admindash" className="nav-link">
              <Button variant="outline-light">📊 Dashboard</Button>
            </NavLink>
            <NavLink to="/managerooms" className="nav-link">
              <Button variant="outline-light">🏠 Manage Rooms</Button>
            </NavLink>
            <NavLink to="/admincomplaint" className="nav-link">
              <Button variant="outline-light">📩 View Complaints</Button>
            </NavLink>
            <NavLink to="/allfeedback" className="nav-link">
              <Button variant="outline-light">📩 Feedback</Button>
            </NavLink>
            <NavLink to="/" className="nav-link">
              <Button variant="outline-danger">🚪 Log Out</Button>
            </NavLink>
          </div>
        </div>

        <div className="main-content">
          <div className="content-container">
            <h3 className="section-title">Complaint List</h3>
            {error ? (
              <p className="error-message">{error}</p>
            ) : (
              <div className="table-container">
                <table className="complaint-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Room No</th>
                      <th>Complaint Type</th>
                      <th>Description</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {complaints.map((complaint) => (
                      <tr key={complaint.id}>
                        <td>{complaint.name}</td>
                        <td>{complaint.roomno}</td>
                        <td>{complaint.complainttype}</td>
                        <td>{complaint.description}</td>
                        <td>{complaint.status}</td>
                        <td>
                          <Button
                            variant="success"
                            onClick={() => updateStatus(complaint.id, "Accepted")}
                          >
                            Accept
                          </Button>{" "}
                          <Button
                            variant="warning"
                            onClick={() => updateStatus(complaint.id, "Processing")}
                          >
                            Process
                          </Button>{" "}
                          <Button
                            variant="danger"
                            onClick={() => updateStatus(complaint.id, "Completed")}
                          >
                            Complete
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admincomplaint;
