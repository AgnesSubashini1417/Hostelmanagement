import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  TextField,
  Paper,
  Container,
} from "@mui/material";
import "./Complaint.css";

const Complaints = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    roomNo: "",
    complaintType: "",
    description: "",
  });

  // Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle complaint submission
  const handleSubmit = async () => {
    if (!formData.name || !formData.roomNo || !formData.complaintType || !formData.description) {
      alert("Please fill all fields before submitting.");
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost/hostelreact/controllers/api/user/complaint.php",
        formData,
        { headers: { "Content-Type": "application/json" } }
      );

      if (response.data.success) {
        alert("Complaint submitted successfully!");
        setFormData({ name: "", roomNo: "", complaintType: "", description: "" });
      } else {
        alert("Failed to submit complaint: " + response.data.message);
      }
    } catch (error) {
      console.error("Error submitting complaint:", error);
      alert("An error occurred. Please try again.");
    }
  };

  // Handle Logout
  const handleLogout = () => {
    navigate("/");
  };

  return (
    <Box className="complaint-container">
      {/* Full-Screen Navbar */}
      <AppBar position="fixed" className="navbar">
        <Toolbar className="navbar-toolbar">
          <Typography variant="h6" className="navbar-title">
            Hostel Management
          </Typography>
          <div className="navbar-buttons">
            <Button color="inherit" onClick={() => navigate("/viewrooms")}>
              View Rooms
            </Button>
            <Button color="inherit" onClick={() => navigate("/complaints")}>
              Complaints
            </Button>
            <Button color="inherit" onClick={() => navigate("/viewcomplaint")}>
              View Complaints
            </Button>
            <Button color="inherit" onClick={() => navigate("/feedback")}>
              Feedback
            </Button>
            <Button color="inherit" className="logout-button" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </Toolbar>
      </AppBar>

      {/* Full-Screen Complaint Form */}
      <Container className="complaint-form-container">
        <Paper elevation={3} className="complaint-form-paper">
          <Typography variant="h5" className="complaint-form-title">
            Complaint Registration
          </Typography>

          <TextField
            label="Your Name"
            variant="outlined"
            fullWidth
            margin="dense"
            name="name"
            value={formData.name}
            onChange={handleChange}
          />

          <TextField
            label="Room Number"
            variant="outlined"
            fullWidth
            margin="dense"
            name="roomNo"
            type="number"
            value={formData.roomNo}
            onChange={handleChange}
          />

          <TextField
            label="Complaint Type (e.g., Maintenance, Noise, Facilities)"
            variant="outlined"
            fullWidth
            margin="dense"
            name="complaintType"
            value={formData.complaintType}
            onChange={handleChange}
          />

          <TextField
            label="Complaint Description"
            variant="outlined"
            fullWidth
            multiline
            rows={4}
            margin="dense"
            name="description"
            value={formData.description}
            onChange={handleChange}
          />

          <Button variant="contained" color="primary" fullWidth onClick={handleSubmit} className="submit-button">
            Submit Complaint
          </Button>
        </Paper>
      </Container>
    </Box>
  );
};

export default Complaints;
