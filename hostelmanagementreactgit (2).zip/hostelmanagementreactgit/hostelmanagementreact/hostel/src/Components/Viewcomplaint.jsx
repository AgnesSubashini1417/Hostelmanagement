import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import "./viewcomplaint.css";

const Viewcomplaint = () => {
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState([]);
  const [error, setError] = useState("");

  // Fetch user-specific complaints
  useEffect(() => {
    axios
      .get("http://localhost/hostelreact/controllers/api/user/getusercomplaints.php", {
        withCredentials: true, // Ensures session authentication
      })
      .then((response) => {
        console.log("Response Data:", response.data); // Debugging
        if (response.data.success) {
          setComplaints(response.data.complaints);
        } else {
          setError(response.data.message);
        }
      })
      .catch((error) => {
        console.error("Error fetching complaints:", error);
        setError("Error fetching complaints");
      });
  }, []);

  return (
    <Box className="complaint-container">
      <AppBar position="fixed" className="navbar">
        <Toolbar className="navbar-toolbar">
          <Typography variant="h6" className="navbar-title">
            Hostel Management
          </Typography>
          <div className="navbar-buttons">
            <Button color="inherit" onClick={() => navigate("/viewrooms")}>
              View Rooms
            </Button>
            <Button color="inherit" onClick={() => navigate("/complaints")}>
              Register Complaint
            </Button>
            <Button color="inherit" onClick={() => navigate("/viewcomplaint")}>
              View Complaints
            </Button>
            <Button color="inherit" onClick={() => navigate("/feedback")}>
              Feedback
            </Button>
            <Button color="inherit" className="logout-button" onClick={() => navigate("/")}>
              Logout
            </Button>
          </div>
        </Toolbar>
      </AppBar>

      {/* Complaints Table */}
      <Box className="complaint-table-container">
        <Typography variant="h5" className="complaint-form-title">
          My Complaints
        </Typography>
        <TableContainer component={Paper} className="table-container">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell><b>Name</b></TableCell>
                <TableCell><b>Room No</b></TableCell>
                <TableCell><b>Complaint Type</b></TableCell>
                <TableCell><b>Description</b></TableCell>
                <TableCell><b>Status</b></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {complaints.length > 0 ? (
                complaints.map((complaint) => (
                  <TableRow key={complaint.id}>
                    <TableCell>{complaint.Name}</TableCell>
                    <TableCell>{complaint.roomno}</TableCell>
                    <TableCell>{complaint.complainttype}</TableCell>
                    <TableCell>{complaint.description}</TableCell>
                    <TableCell>{complaint.status}</TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} align="center">{error || "No complaints found."}</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </Box>
  );
};

export default Viewcomplaint;
