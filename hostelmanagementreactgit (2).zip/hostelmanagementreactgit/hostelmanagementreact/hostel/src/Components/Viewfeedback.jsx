import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import "./ViewFeedback.css";

const ViewFeedback = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    axios
      .get("http://localhost/hostelreact/controllers/api/admin/getallfeedback.php", {
        withCredentials: true,
      })
      .then((response) => {
        if (response.data.success) {
          setFeedbacks(response.data.feedbacks);
        } else {
          setError("No feedback available.");
        }
      })
      .catch((error) => {
        console.error("Error fetching feedback:", error);
        setError("Failed to fetch feedback data.");
      });
  }, []);

  return (
    <div className="admin-dashboard">
      {/* Header */}
      <div className="header">
        <h2>🏠 Hostel Management System</h2>
      </div>

      {/* Sidebar & Main Content */}
      <div className="dashboard-body">
        {/* Sidebar */}
        <div className="sidebar">
          <div className="sidebar-content">
            <NavLink to="/admindash" className="nav-link">
              <Button variant="outline-light">📊 Dashboard</Button>
            </NavLink>
            <NavLink to="/studentreg" className="nav-link">
              <Button variant="outline-light">📝 View Student Registration</Button>
            </NavLink>
            <NavLink to="/managerooms" className="nav-link">
              <Button variant="outline-light">🏠 Manage Rooms</Button>
            </NavLink>
            <NavLink to="/admincomplaint" className="nav-link">
              <Button variant="outline-light">📩 View Complaints</Button>
            </NavLink>
            <NavLink to="/allfeedback" className="nav-link">
              <Button variant="outline-light">💬 Feedback</Button>
            </NavLink>
            <NavLink to="/" className="nav-link">
              <Button variant="outline-danger">🚪 Log Out</Button>
            </NavLink>
          </div>
        </div>

        {/* Main Content */}
        <div className="main-content">
          <div className="content-container">
            <h3 className="section-title">💬 Hostel Feedbacks</h3>

            {error ? (
              <p className="error-message">{error}</p>
            ) : (
              <div className="table-container">
                <table className="student-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Room No</th>
                      <th>Warden</th>
                      <th>Hostel Committee</th>
                      <th>Room Condition</th>
                      <th>Mess Quality</th>
                      <th>Surroundings</th>
                      <th>Rating</th>
                      <th>Message</th>
                    </tr>
                  </thead>
                  <tbody>
                    {feedbacks.length > 0 ? (
                      feedbacks.map((feedback, index) => (
                        <tr key={index}>
                          <td>{feedback.Name}</td>
                          <td>{feedback.roomno}</td>
                          <td>{feedback.warden}</td>
                          <td>{feedback.Hostelcomittee}</td>
                          <td>{feedback.roomcondition}</td>
                          <td>{feedback.messquality}</td>
                          <td>{feedback.hostelsurrounding}</td>
                          <td>{feedback.rating}</td>
                          <td>{feedback.message}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="9" className="error-message">
                          {error || "No feedback found."}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewFeedback;
