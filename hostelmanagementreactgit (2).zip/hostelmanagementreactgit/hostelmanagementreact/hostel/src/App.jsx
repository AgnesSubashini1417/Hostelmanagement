import React from 'react'
import Home from './Components/Home'
import { BrowserRouter,Routes,Route } from "react-router-dom";
import Adminlogin from './Components/Adminlogin';
import Userlogin from './Components/Userlogin';
import Admindashboard from './Components/Admindashboard';
import Register from './Components/Register';
import Userdashboard from './Components/Userdashboard';
import Complaints from './Components/Complaint';
import Viewcomplaint from './Components/Viewcomplaint';
import Feedback from './Components/Feedbackform';
import StudentRegistration from './Components/Viewstudent';
import ManageRooms from './Components/Managerooms';
import Admincomplaint from './Components/Admincomplaint';
import ViewFeedback from './Components/Viewfeedback';

function App() {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/adminlogin' element={<Adminlogin/>}/>
        <Route path='/userlogin' element={<Userlogin/>}/>
        <Route path='/admindash' element={<Admindashboard/>}/>
        <Route path='/register' element={<Register/>}/>
        <Route path='/userdashboard' element={<Userdashboard/>}/>
        <Route path='/complaints' element={<Complaints/>}/>
        <Route path='/viewcomplaint' element={<Viewcomplaint/>}/>
        <Route path='/feedback' element={<Feedback/>}/>
        <Route path='/studentreg' element={<StudentRegistration/>}/>
        <Route path='/managerooms' element={<ManageRooms/>}/>
        <Route path='/admincomplaint' element={<Admincomplaint/>}/>
        <Route path='/allfeedback' element={<ViewFeedback/>}/>











      </Routes>
      </BrowserRouter>
      

    
    </div>
  )
}

export default App
