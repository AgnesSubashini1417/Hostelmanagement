<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel"; // Change to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed"]));
}

// Handle GET request to fetch complaints
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $sql = "SELECT id, name, roomno, complainttype, description, status FROM complaint";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $complaints = [];
        while ($row = $result->fetch_assoc()) {
            $complaints[] = $row;
        }
        echo json_encode(["success" => true, "complaints" => $complaints]);
    } else {
        echo json_encode(["success" => false, "message" => "No complaints found"]);
    }
}

// Handle POST request to update complaint status
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data["id"]) && isset($data["status"])) {
        $id = intval($data["id"]);
        $status = $data["status"];

        $updateSql = "UPDATE complaint SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("si", $status, $id);

        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Complaint status updated successfully"]);
        } else {
            echo json_encode(["success" => false, "message" => "Failed to update status"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["success" => false, "message" => "Invalid input"]);
    }
}

$conn->close();
?>
