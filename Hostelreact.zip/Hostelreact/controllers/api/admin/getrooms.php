<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel"; // Change to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Connection failed"]));
}

$sql = "SELECT roomno, room, price, name, regno, contact, guardian, address, joindate FROM roomregister"; // Change "rooms" to your actual table name
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $rooms = [];
    while ($row = $result->fetch_assoc()) {
        $rooms[] = $row;
    }
    echo json_encode(["success" => true, "rooms" => $rooms]);
} else {
    echo json_encode(["success" => false, "message" => "No room data available"]);
}

$conn->close();
?>
