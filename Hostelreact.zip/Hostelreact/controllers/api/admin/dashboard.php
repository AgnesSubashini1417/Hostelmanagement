<?php
session_start();
session_regenerate_id(true); // Prevent session fixation attacks

// Allow frontend access
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Fetch total students
$studentQuery = "SELECT COUNT(*) AS total_students FROM userlogin";
$studentResult = $conn->query($studentQuery);
$total_students = $studentResult->fetch_assoc()['total_students'];

// Fetch total complaints
$complaintQuery = "SELECT COUNT(*) AS total_complaints FROM complaint";
$complaintResult = $conn->query($complaintQuery);
$total_complaints = $complaintResult->fetch_assoc()['total_complaints'];

// Fetch total feedback
$feedbackQuery = "SELECT COUNT(*) AS total_feedback FROM feedback";
$feedbackResult = $conn->query($feedbackQuery);
$total_feedback = $feedbackResult->fetch_assoc()['total_feedback'];

echo json_encode([
    'success' => true,
    'total_students' => $total_students,
    'total_complaints' => $total_complaints,
    'total_feedback' => $total_feedback
]);

$conn->close();
?>
