<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Decode JSON request
$data = json_decode(file_get_contents("php://input"), true);

$roomNo = $data['roomNo'] ?? null;
$room = $data['room'] ?? null;
$price = $data['price'] ?? null;
$name = $data['name'] ?? null;
$regNo = $data['regNo'] ?? null;
$contact = $data['contact'] ?? null;
$guardian = $data['guardian'] ?? null;
$address = $data['address'] ?? null;
$permanentAddress = $data['permanentAddress'] ?? null;
$joinDate = $data['joinDate'] ?? null;

// Validate required fields
if (!$roomNo || !$room || !$price || !$name || !$regNo || !$contact || !$joinDate) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All required fields must be filled']);
    exit();
}

// Insert into database
$sql = "INSERT INTO roomregister (roomno, room, price, Name, Regno, Contact, Guardian, address, Permanentaddress, joindate) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("isdsssssss", $roomNo, $room, $price, $name, $regNo, $contact, $guardian, $address, $permanentAddress, $joinDate);

if ($stmt->execute()) {
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Room booked successfully']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to book room']);
}

$stmt->close();
$conn->close();
?>
