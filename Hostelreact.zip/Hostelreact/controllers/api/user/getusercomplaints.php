<?php
session_start();
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Debugging: Log session email
error_log("Session Email: " . ($_SESSION['email'] ?? 'No session found'));
error_log("Session Name: " . ($_SESSION['name'] ?? 'No session found'));

// Check if user is logged in
if (!isset($_SESSION['email']) || !isset($_SESSION['name'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized - No session data']);
    exit();
}

$name = $_SESSION['name']; // Get user's name from session

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Fetch complaints where 'Name' matches logged-in user's name
$sql = "SELECT id, Name, roomno, complainttype, description, status FROM complaint WHERE Name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $name);
$stmt->execute();
$result = $stmt->get_result();

$complaints = [];
while ($row = $result->fetch_assoc()) {
    $complaints[] = $row;
}

// Send response
http_response_code(200);
echo json_encode(['success' => true, 'complaints' => $complaints]);

$stmt->close();
$conn->close();
?>
