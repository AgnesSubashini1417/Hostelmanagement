<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Decode JSON request
$data = json_decode(file_get_contents("php://input"), true);

$name = $data['name'] ?? null;
$roomNo = $data['roomNo'] ?? null;
$warden = $data['warden'] ?? null;
$committee = $data['committee'] ?? null;
$room = $data['room'] ?? null;
$mess = $data['mess'] ?? null;
$surrounding = $data['surrounding'] ?? null;
$rating = $data['rating'] ?? null;
$message = $data['message'] ?? null;

// Validate required fields
if (!$name || !$roomNo || !$warden || !$committee || !$room || !$mess || !$surrounding || !$rating || !$message) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

// Insert into database
$sql = "INSERT INTO feedback (Name, roomno, warden, Hostelcomittee, roomcondition, messquality, hostelsurrounding, rating, message) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssss", $name, $roomNo, $warden, $committee, $room, $mess, $surrounding, $rating, $message);

if ($stmt->execute()) {
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Feedback submitted successfully']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to submit feedback']);
}

$stmt->close();
$conn->close();
?>
