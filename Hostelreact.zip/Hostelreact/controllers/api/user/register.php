<?php
// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit;
}

// Decode incoming JSON data
$data = json_decode(file_get_contents("php://input"), true);

// Ensure data is received correctly
if (!isset($data['name']) || !isset($data['age']) || !isset($data['fathername']) ||
    !isset($data['Gender']) || !isset($data['phoneno']) || !isset($data['email']) ||
    !isset($data['password']) || !isset($data['address'])) {
    
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Get data safely
$name = $conn->real_escape_string($data['name']);
$age = (int) $data['age'];
$fathername = $conn->real_escape_string($data['fathername']);
$gender = $conn->real_escape_string($data['Gender']);
$phoneno = $conn->real_escape_string($data['phoneno']);
$email = $conn->real_escape_string($data['email']);
$password = $conn->real_escape_string($data['password']);
$address = $conn->real_escape_string($data['address']);

// Check if user already exists
$check = "SELECT * FROM userlogin WHERE email = '$email'";
$result = $conn->query($check);

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Email already registered']);
} else {
    // Insert user
    $sql = "INSERT INTO userlogin (name, age, fathername, Gender, phoneno, email, password, address) 
            VALUES ('$name', '$age', '$fathername', '$gender', '$phoneno', '$email', '$password', '$address')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Registration successful']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

$conn->close();
?>
